declare function require(name : string) :void;
declare var module : any;